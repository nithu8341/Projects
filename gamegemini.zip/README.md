# GameGemini

AI-powered text-based adventure game using Google's Generative AI.

## Features

- Randomly generates a game scenario
- Interactive gameplay loop with AI responses
- Text-only terminal experience

## Setup

1. Clone the repository:
   ```bash
   git clone https://github.com/yourusername/gamegemini.git
   cd gamegemini
   ```

2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

3. Set up your `.env` file with your Google API key:
   ```env
   GOOGLE_API_KEY=your_api_key
   ```

4. Run the game:
   ```bash
   python gamegemini.py
   ```

## Notes

- Make sure you have access to Google Generative AI API.
- This is a terminal-based game—enjoy the retro text adventure vibes!
